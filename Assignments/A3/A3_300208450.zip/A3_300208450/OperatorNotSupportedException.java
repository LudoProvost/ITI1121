public class OperatorNotSupportedException extends Throwable {
}
