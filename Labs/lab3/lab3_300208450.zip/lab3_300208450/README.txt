Student name: Ludovic Provost
Student number: 300208450
Course code: ITI1121
Lab section: Z-2

This archive contains the 3 files of the lab 3, that is, this file (README.txt),
plus the files Utils.java and Rational.java.