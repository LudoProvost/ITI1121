public interface Series {

    double next();
    
}
