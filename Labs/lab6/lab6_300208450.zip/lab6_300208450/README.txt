Student name: Ludovic Provost
Student number: 300208450
Course code: ITI1121
Lab section: B-2

This archive contains the 7 files of lab 6, that is, this file (README.txt),
plus ArrayStack.java, Dictionary.java, DynamicArrayStack.java, Pair.java, Map.java, Stack.java.