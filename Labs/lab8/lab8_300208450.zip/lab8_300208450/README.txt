Student name: Ludovic Provost
Student number: 300208450
Course code: ITI1121
Lab section: B-2

This archive contains the 5 files of lab 8, that is, this file (README.txt),
plus Queue.java, ArrayQueue.java, Customer.java, Cashier.java.