public class FullStackException extends IllegalStateException {

    public FullStackException() {
        super("The stack is full.");
    }

}
